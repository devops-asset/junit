package com.javafortesters.domainentities.interim.exceptions.custom;

public class InvalidPassword extends Exception {
    public InvalidPassword(String message) {
        super(message);
    }
}
