/*
package com.javafortesters.domainobject;

public class TestAppEnv {

    public static String getUrl() {
        return null;
    }
}
*/


package com.javafortesters.domainobject.interim;

public class TestAppEnv {

    public static String getUrl() {
        return "http://192.123.0.3:67";
    }
}
