package com.javafortesters.chap001basicsofjava.examples.classes;

public class AnEmptyClass {
}
