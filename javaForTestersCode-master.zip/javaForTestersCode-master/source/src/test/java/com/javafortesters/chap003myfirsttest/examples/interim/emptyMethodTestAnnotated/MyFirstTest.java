package com.javafortesters.chap003myfirsttest.examples.interim.emptyMethodTestAnnotated;


import org.junit.Test;

public class MyFirstTest {

    @Test
    public void canAddTwoPlusTwo(){
    }
}