package com.javafortesters.chap006domainentities.exercises.publicfields;


public class User {
    public String username;
    public String password;

    public User(){
        username = "admin";
        password = "pA55w0rD";
    }
}
