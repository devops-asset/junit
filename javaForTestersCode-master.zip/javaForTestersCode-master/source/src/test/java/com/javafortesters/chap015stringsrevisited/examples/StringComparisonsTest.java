package com.javafortesters.chap015stringsrevisited.examples;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class StringComparisonsTest {

    @Test
    public void canCompareToString(){
        String hello = "Hello";
        assertThat(hello.compareTo("Hello"), is(0));

        assertThat(hello.compareTo("hello") < 0, is(true));
        assertThat(hello.compareTo("Helloo") < 0, is(true));
        assertThat(hello.compareTo("Hemlo") < 0, is(true));

        assertThat(hello.compareTo("H") > 0, is(true));
        assertThat(hello.compareTo("Helln") > 0, is(true));
        assertThat(hello.compareTo("HeLlo") > 0, is(true));

        assertThat(hello.compareToIgnoreCase("hello"), is(0));
        assertThat(hello.compareToIgnoreCase("Hello"), is(0));
        assertThat(hello.compareToIgnoreCase("HeLlo"), is(0));
    }

    @Test
    public void canCheckContainsOnString(){
        String hello = "Hello";
        assertThat(hello.contains("He"), is(true));
        assertThat(hello.contains("Hello"), is(true));

        assertThat(hello.contains("LL"), is(false));

        assertThat(hello.contains("z"), is(false));
        assertThat(hello.contains("world"), is(false));
        assertThat(hello.contains("Helloo"), is(false));
    }

    @Test
    public void canCheckContentEquals(){
        String hello = "Hello";
        assertThat(hello.contentEquals("Hello"), is(true));
        assertThat(hello.contentEquals("hello"), is(false));

        assertThat(hello.equalsIgnoreCase("hello"), is(true));
    }

    @Test
    public void canCheckEndsWithStartsWith(){
        String hello = "Hello";
        assertThat(hello.endsWith("Hello"), is(true));
        assertThat(hello.endsWith(""), is(true));
        assertThat(hello.endsWith("lo"), is(true));

        assertThat(hello.startsWith("Hello"), is(true));
        assertThat(hello.endsWith(""), is(true));
        assertThat(hello.startsWith("He"), is(true));

        assertThat(hello.startsWith("he"), is(false));
        assertThat(hello.startsWith("Lo"), is(false));
    }

    @Test
    public void canCheckEmpty(){

        String empty = "";
        assertThat(empty.isEmpty(), is(true));
        assertThat(empty.length(), is(0));

        String notEmpty = " ";
        assertThat(notEmpty.isEmpty(), is(false));
        assertThat(notEmpty.length(), is(1));
    }

    @Test
    public void canFindIndexOf(){
        /*
         "Hello fella"
          01234567890
         */
        String hello = "Hello fella";

        assertThat(hello.indexOf("l"), is(2));
        assertThat(hello.lastIndexOf("l"), is(9));

        assertThat(hello.indexOf('l',3), is(3));
        assertThat(hello.indexOf("l",4), is(8));

        assertThat(hello.lastIndexOf('l',8), is(8));
        assertThat(hello.lastIndexOf("l",7), is(3));


        assertThat(hello.indexOf('z'), is(-1));
        assertThat(hello.lastIndexOf("z"), is(-1));
    }


    @Test
    public void checkRegionMatches(){

        String hello = "Hello fella";
        assertThat(
                hello.regionMatches(true, 6, "fez", 0, 2),
                is(true));

        // case insensitive search
        assertThat(
                hello.regionMatches(true, 0, "he", 0, 2),
                is(true));

        // case sensitive search
        assertThat(
                hello.regionMatches(false, 0, "hE", 0, 2),
                is(false));
        assertThat(
                hello.regionMatches(0, "hE", 0, 2),
                is(false));
        assertThat(
                hello.regionMatches(0, "He", 0, 2),
                is(true));

        assertFalse(
                hello.regionMatches(true, 3, "lady", 0, 2));
        assertFalse(
                hello.regionMatches(true, 3, "young lady", 6, 2));

        // search for lo
        assertTrue(
                hello.regionMatches(true, 3, "lololo", 0, 2));
    }


}