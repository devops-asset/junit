package com.javafortesters.chap001basicsofjava.examples.classes;

public class AClassWithAMethod {

    public void aMethodOnAClass(){
        System.out.println("Hello World");
    }
}
