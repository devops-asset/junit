package com.javafortesters.chap003myfirsttest.examples.interim.emptyMethod;

public class MyFirstTest {

    public void canAddTwoPlusTwo(){
    }
}
