package com.javafortesters.chap012inheritance.examples;

import com.javafortesters.domainentities.User;

public class EmptyUser extends User {
}
