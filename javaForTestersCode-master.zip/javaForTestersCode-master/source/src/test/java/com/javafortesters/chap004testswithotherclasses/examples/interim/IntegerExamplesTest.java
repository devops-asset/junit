package com.javafortesters.chap004testswithotherclasses.examples.interim;
import org.junit.Test;

public class IntegerExamplesTest {

    @Test
    public void integerExploration(){
    }
}
