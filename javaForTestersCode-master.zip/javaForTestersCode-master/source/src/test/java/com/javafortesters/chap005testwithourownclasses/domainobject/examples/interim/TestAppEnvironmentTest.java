/*
package com.javafortesters.chap005testwithourownclasses.domainobject.examples;

public class TestAppEnvironmentTest {
}
*/


package com.javafortesters.chap005testwithourownclasses.domainobject.examples.interim;

import org.junit.Test;

public class TestAppEnvironmentTest {

    @Test
    public void canGetUrlStatically(){
    }
}