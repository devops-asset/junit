package com.javafortesters.chap003myfirsttest.examples.interim.emptyWithTemplate;

/**
 * Created with IntelliJ IDEA.
 * User: Alan
 * Date: 24/04/13
 * Time: 11:48
 * To change this template use File | Settings | File Templates.
 */

public class MyFirstTest {
}
